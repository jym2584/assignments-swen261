package rit.calculator;

public interface BinaryOperator {

    double apply(double arg1, double arg2);

}
